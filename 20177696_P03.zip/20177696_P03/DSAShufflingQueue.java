import java.util.*;
public class DSAShufflingQueue extends DSAQueue
{
    private Object[] queue;

    public DSAShufflingQueue()
    {
        super();
    }

    public DSAShufflingQueue(int maxCapacity)
    {
        super(maxCapacity);
    }
}
